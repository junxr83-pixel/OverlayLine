package com.example.overlayline;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {
    public static final String ACTION_START = "START";
    public static final String ACTION_SET_LENGTH = "SET_LENGTH";
    public static final String ACTION_SET_ANGLE = "SET_ANGLE";

    private WindowManager wm;
    private LineView line;
    private WindowManager.LayoutParams params;
    private int length = 180;
    private int angle = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, "overlay_line")
                .setContentTitle("Overlay Line aktif")
                .setContentText("Seret ujung bulat untuk mengubah panjang dan sudut.")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setOngoing(true)
                .build();
        startForeground(1001, n);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_SET_LENGTH.equals(intent.getAction())) {
            length = clamp(intent.getIntExtra("length", 180), 20, 4000);
            if (line != null) line.updateGeometry();
        } else if (intent != null && ACTION_SET_ANGLE.equals(intent.getAction())) {
            angle = ((intent.getIntExtra("angle", 0) % 360) + 360) % 360;
            if (line != null) line.invalidate();
        } else if (line == null && Settings.canDrawOverlays(this)) {
            showLine();
        }
        return START_STICKY;
    }

    private int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private void showLine() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int size = length + 120;
        params = new WindowManager.LayoutParams(
                size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 400;

        line = new LineView();
        wm.addView(line, params);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    "overlay_line", "Overlay Line",
                    android.app.NotificationManager.IMPORTANCE_LOW);
            getSystemService(android.app.NotificationManager.class).createNotificationChannel(c);
        }
    }

    private class LineView extends View {
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float handleRadius = 18f;
        private final float touchRadius = 55f;

        private static final int NONE = 0;
        private static final int MOVE = 1;
        private static final int END_A = 2;
        private static final int END_B = 3;
        private int mode = NONE;
        private float downRawX, downRawY;
        private int startWindowX, startWindowY;

        LineView() {
            super(OverlayService.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            linePaint.setColor(Color.WHITE);
            linePaint.setStrokeWidth(7f);
            linePaint.setStrokeCap(Paint.Cap.ROUND);
            linePaint.setShadowLayer(5f, 0f, 0f, Color.BLACK);
            handlePaint.setColor(Color.WHITE);
            handlePaint.setStyle(Paint.Style.FILL);
            handlePaint.setShadowLayer(5f, 0f, 0f, Color.BLACK);
            setBackgroundColor(Color.TRANSPARENT);
            setClickable(true);
        }

        void updateGeometry() {
            if (wm == null) return;
            int newSize = length + 120;
            params.width = newSize;
            params.height = newSize;
            try { wm.updateViewLayout(this, params); } catch (Exception ignored) {}
            invalidate();
        }

        private float cx() { return getWidth() / 2f; }
        private float cy() { return getHeight() / 2f; }
        private float rad() { return (float) Math.toRadians(angle); }
        private float half() { return length / 2f; }

        private float ax() { return cx() - (float)Math.cos(rad()) * half(); }
        private float ay() { return cy() - (float)Math.sin(rad()) * half(); }
        private float bx() { return cx() + (float)Math.cos(rad()) * half(); }
        private float by() { return cy() + (float)Math.sin(rad()) * half(); }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float ax = ax(), ay = ay(), bx = bx(), by = by();
            canvas.drawLine(ax, ay, bx, by, linePaint);
            canvas.drawCircle(ax, ay, handleRadius, handlePaint);
            canvas.drawCircle(bx, by, handleRadius, handlePaint);
        }

        private float distance(float x1, float y1, float x2, float y2) {
            return (float)Math.hypot(x1 - x2, y1 - y2);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX();
            float y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = e.getRawX();
                    downRawY = e.getRawY();
                    startWindowX = params.x;
                    startWindowY = params.y;
                    float da = distance(x, y, ax(), ay());
                    float db = distance(x, y, bx(), by());
                    if (da <= touchRadius) mode = END_A;
                    else if (db <= touchRadius) mode = END_B;
                    else mode = MOVE;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (mode == MOVE) {
                        params.x = startWindowX + Math.round(e.getRawX() - downRawX);
                        params.y = startWindowY + Math.round(e.getRawY() - downRawY);
                        try { wm.updateViewLayout(this, params); } catch (Exception ignored) {}
                    } else if (mode == END_A || mode == END_B) {
                        // Dragging either end changes both length and rotation.
                        float anchorX = mode == END_A ? bx() : ax();
                        float anchorY = mode == END_A ? by() : ay();
                        float dx = x - anchorX;
                        float dy = y - anchorY;
                        float newLength = (float)Math.hypot(dx, dy);
                        length = clamp(Math.round(newLength), 20, 4000);
                        angle = Math.round((float)Math.toDegrees(Math.atan2(dy, dx)));
                        if (mode == END_A) angle = (angle + 180) % 360;
                        angle = (angle + 360) % 360;
                        updateGeometry();
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    mode = NONE;
                    return true;
            }
            return true;
        }
    }

    @Override
    public void onDestroy() {
        if (line != null && wm != null) {
            try { wm.removeView(line); } catch (Exception ignored) {}
            line = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}

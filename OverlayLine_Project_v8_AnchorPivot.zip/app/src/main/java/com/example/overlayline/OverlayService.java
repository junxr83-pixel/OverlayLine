package com.example.overlayline;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.Service;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {
    public static final String ACTION_START = "START";
    public static final String ACTION_SET_LENGTH = "SET_LENGTH";
    public static final String ACTION_SET_ANGLE = "SET_ANGLE";

    private WindowManager wm;
    private LineView lineView;
    // Point 1 = fixed anchor (not touchable), Point 2 = move handle, Point 3 = rotate/length handle.
    private HandleView handle2, handle3;
    private WindowManager.LayoutParams p2, p3, lineParams;

    private float anchorX = 540f; // Point 1
    private float anchorY = 900f;
    private float length = 420f;
    private float angle = 0f;
    private final float HANDLE2_FRACTION = 0.38f;

    private final int HANDLE_SIZE = 56;
    private final int HALF_HANDLE = HANDLE_SIZE / 2;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, "overlay_line")
                .setContentTitle("Overlay Line aktif")
                .setContentText("Titik 2 untuk geser. Titik 3 untuk putar dan atur panjang.")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setOngoing(true).build();
        startForeground(1001, n);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_SET_LENGTH.equals(intent.getAction())) {
            length = clamp(intent.getIntExtra("length", (int) length), 20, 10000);
            updateAll();
        } else if (intent != null && ACTION_SET_ANGLE.equals(intent.getAction())) {
            angle = normalize(intent.getIntExtra("angle", (int) angle));
            updateAll();
        } else if (lineView == null && Settings.canDrawOverlays(this)) {
            showOverlay();
        }
        return START_STICKY;
    }

    private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private float normalize(float a) { a %= 360f; return a < 0 ? a + 360f : a; }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private WindowManager.LayoutParams baseParams(int w, int h, boolean touchable) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        if (!touchable) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        return new WindowManager.LayoutParams(w, h, overlayType(), flags, PixelFormat.TRANSLUCENT);
    }

    private void showOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        anchorX = dm.widthPixels * 0.30f;
        anchorY = dm.heightPixels * 0.50f;
        length = Math.min(700f, dm.widthPixels * 0.62f);
        angle = 0f;

        // Visual layer never receives touches.
        lineParams = baseParams(dm.widthPixels, dm.heightPixels, false);
        lineParams.gravity = Gravity.TOP | Gravity.START;
        lineParams.x = 0; lineParams.y = 0;
        lineView = new LineView();
        wm.addView(lineView, lineParams);

        handle2 = new HandleView(HandleView.MOVE);
        handle3 = new HandleView(HandleView.ROTATE);
        p2 = baseParams(HANDLE_SIZE, HANDLE_SIZE, true);
        p3 = baseParams(HANDLE_SIZE, HANDLE_SIZE, true);
        p2.gravity = p3.gravity = Gravity.TOP | Gravity.START;
        wm.addView(handle2, p2);
        wm.addView(handle3, p3);
        updateAll();
    }

    private float rad() { return (float) Math.toRadians(angle); }

    private float x1() { return anchorX; }
    private float y1() { return anchorY; }
    private float x3() { return anchorX + (float)Math.cos(rad()) * length; }
    private float y3() { return anchorY + (float)Math.sin(rad()) * length; }
    private float x2() { return anchorX + (float)Math.cos(rad()) * length * HANDLE2_FRACTION; }
    private float y2() { return anchorY + (float)Math.sin(rad()) * length * HANDLE2_FRACTION; }

    private void putAt(WindowManager.LayoutParams p, float x, float y) {
        p.x = Math.round(x - HALF_HANDLE);
        p.y = Math.round(y - HALF_HANDLE);
    }

    private void updateAll() {
        if (wm == null) return;
        if (lineView != null) lineView.invalidate();
        if (p2 != null) putAt(p2, x2(), y2());
        if (p3 != null) putAt(p3, x3(), y3());
        try {
            if (handle2 != null) wm.updateViewLayout(handle2, p2);
            if (handle3 != null) wm.updateViewLayout(handle3, p3);
        } catch (Exception ignored) {}
    }

    private class LineView extends View {
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint anchor = new Paint(Paint.ANTI_ALIAS_FLAG);
        LineView() {
            super(OverlayService.this);
            line.setColor(Color.WHITE);
            line.setStrokeWidth(3f);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setShadowLayer(4f, 0, 0, Color.BLACK);
            anchor.setColor(Color.BLACK);
            anchor.setStyle(Paint.Style.FILL);
            anchor.setShadowLayer(5f, 0, 0, Color.WHITE);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            // Point 1 is deliberately drawn larger, black, and is not touchable.
            c.drawLine(x1(), y1(), x3(), y3(), line);
            c.drawCircle(x1(), y1(), 16f, anchor);
        }
    }

    private class HandleView extends View {
        static final int MOVE = 2, ROTATE = 3;
        private final int type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float downRawX, downRawY;
        private float startAnchorX, startAnchorY;

        HandleView(int type) {
            super(OverlayService.this);
            this.type = type;
            p.setColor(Color.WHITE);
            p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(5f, 0, 0, Color.BLACK);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setClickable(true);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float r = type == ROTATE ? 9f : 10f;
            c.drawCircle(getWidth()/2f, getHeight()/2f, r, p);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float rawX = e.getRawX(), rawY = e.getRawY();
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                downRawX = rawX; downRawY = rawY;
                startAnchorX = anchorX; startAnchorY = anchorY;
                return true;
            }
            if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                if (type == MOVE) {
                    // Point 2 translates the whole guide, including the anchor.
                    anchorX = startAnchorX + (rawX - downRawX);
                    anchorY = startAnchorY + (rawY - downRawY);
                } else {
                    // Point 3 rotates and resizes around Point 1.
                    // Point 1 remains exactly where it was.
                    float dx = rawX - anchorX;
                    float dy = rawY - anchorY;
                    float d = (float)Math.hypot(dx, dy);
                    if (d > 8f) {
                        length = clamp(d, 20f, 10000f);
                        angle = normalize((float)Math.toDegrees(Math.atan2(dy, dx)));
                    }
                }
                updateAll();
                return true;
            }
            return true;
        }
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (wm == null) return;
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        anchorX = clamp(anchorX, 0f, dm.widthPixels);
        anchorY = clamp(anchorY, 0f, dm.heightPixels);
        if (lineParams != null) {
            lineParams.width = dm.widthPixels;
            lineParams.height = dm.heightPixels;
            try { wm.updateViewLayout(lineView, lineParams); } catch (Exception ignored) {}
        }
        updateAll();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("overlay_line", "Overlay Line", android.app.NotificationManager.IMPORTANCE_LOW);
            getSystemService(android.app.NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        if (wm != null) {
            try { if (handle2 != null) wm.removeView(handle2); } catch (Exception ignored) {}
            try { if (handle3 != null) wm.removeView(handle3); } catch (Exception ignored) {}
            try { if (lineView != null) wm.removeView(lineView); } catch (Exception ignored) {}
        }
        handle2 = handle3 = null; lineView = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}

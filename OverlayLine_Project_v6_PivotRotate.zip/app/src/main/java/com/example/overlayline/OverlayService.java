package com.example.overlayline;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {
    public static final String ACTION_START = "START";
    public static final String ACTION_SET_LENGTH = "SET_LENGTH";
    public static final String ACTION_SET_ANGLE = "SET_ANGLE";

    private WindowManager wm;
    private LineView lineView;
    private HandleView handleA, handleB, handleCenter;
    private WindowManager.LayoutParams lineParams, aParams, bParams, centerParams;

    private float centerX = 540f;
    private float centerY = 900f;
    private float length = 260f;
    private float angle = 0f;

    private final int HANDLE_SIZE = 96;
    private final int HALF_HANDLE = HANDLE_SIZE / 2;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, "overlay_line")
                .setContentTitle("Overlay Line aktif")
                .setContentText("Tarik bulatan ujung untuk panjang + putar. Tarik tengah untuk memindahkan.")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setOngoing(true).build();
        startForeground(1001, n);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_SET_LENGTH.equals(intent.getAction())) {
            length = clamp(intent.getIntExtra("length", (int) length), 20, 5000);
            updateAll();
        } else if (intent != null && ACTION_SET_ANGLE.equals(intent.getAction())) {
            angle = normalize(intent.getIntExtra("angle", (int) angle));
            updateAll();
        } else if (lineView == null && Settings.canDrawOverlays(this)) {
            showOverlay();
        }
        return START_STICKY;
    }

    private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private float normalize(float a) { a %= 360f; return a < 0 ? a + 360f : a; }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private WindowManager.LayoutParams baseParams(int w, int h, boolean touchable) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        if (!touchable) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        return new WindowManager.LayoutParams(w, h, overlayType(), flags, PixelFormat.TRANSLUCENT);
    }

    private void showOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        centerX = dm.widthPixels / 2f;
        centerY = dm.heightPixels / 2f;

        // Full-screen visual layer. It NEVER receives touches, so the app below remains usable.
        lineParams = baseParams(dm.widthPixels, dm.heightPixels, false);
        lineParams.gravity = Gravity.TOP | Gravity.START;
        lineParams.x = 0; lineParams.y = 0;
        lineView = new LineView();
        wm.addView(lineView, lineParams);

        handleA = new HandleView(HandleView.END_A);
        handleB = new HandleView(HandleView.END_B);
        handleCenter = new HandleView(HandleView.CENTER);

        aParams = baseParams(HANDLE_SIZE, HANDLE_SIZE, true);
        bParams = baseParams(HANDLE_SIZE, HANDLE_SIZE, true);
        centerParams = baseParams(HANDLE_SIZE, HANDLE_SIZE, true);
        aParams.gravity = bParams.gravity = centerParams.gravity = Gravity.TOP | Gravity.START;

        wm.addView(handleA, aParams);
        wm.addView(handleB, bParams);
        wm.addView(handleCenter, centerParams);
        updateAll();
    }

    private float rad() { return (float) Math.toRadians(angle); }
    private float ax() { return centerX - (float)Math.cos(rad()) * length / 2f; }
    private float ay() { return centerY - (float)Math.sin(rad()) * length / 2f; }
    private float bx() { return centerX + (float)Math.cos(rad()) * length / 2f; }
    private float by() { return centerY + (float)Math.sin(rad()) * length / 2f; }

    private void putAt(WindowManager.LayoutParams p, float x, float y) {
        p.x = Math.round(x - HALF_HANDLE);
        p.y = Math.round(y - HALF_HANDLE);
    }

    private void updateAll() {
        if (wm == null) return;
        if (lineView != null) lineView.invalidate();
        if (aParams != null) putAt(aParams, ax(), ay());
        if (bParams != null) putAt(bParams, bx(), by());
        if (centerParams != null) putAt(centerParams, centerX, centerY);
        try {
            if (handleA != null) wm.updateViewLayout(handleA, aParams);
            if (handleB != null) wm.updateViewLayout(handleB, bParams);
            if (handleCenter != null) wm.updateViewLayout(handleCenter, centerParams);
        } catch (Exception ignored) {}
    }

    private class LineView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        LineView() {
            super(OverlayService.this);
            p.setColor(Color.WHITE); p.setStrokeWidth(7f); p.setStrokeCap(Paint.Cap.ROUND);
            p.setShadowLayer(5f, 0, 0, Color.BLACK);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawLine(ax(), ay(), bx(), by(), p);
        }
    }

    private class HandleView extends View {
        static final int END_A = 1, END_B = 2, CENTER = 3;
        private final int type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float downRawX, downRawY;
        private float startCenterX, startCenterY;
        private float startAX, startAY, startBX, startBY;

        HandleView(int type) {
            super(OverlayService.this); this.type = type;
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(5f, 0, 0, Color.BLACK);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setClickable(true);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawCircle(getWidth()/2f, getHeight()/2f, 20f, p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float rawX = e.getRawX(), rawY = e.getRawY();
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                downRawX = rawX; downRawY = rawY;
                startCenterX = centerX; startCenterY = centerY;
                startAX = ax(); startAY = ay(); startBX = bx(); startBY = by();
                return true;
            }
            if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                if (type == CENTER) {
                    centerX = startCenterX + (rawX - downRawX);
                    centerY = startCenterY + (rawY - downRawY);
                } else {
                    // The center/pivot stays fixed. Dragging either endpoint
                    // changes BOTH the length and angle around that pivot.
                    float dx = rawX - centerX;
                    float dy = rawY - centerY;
                    float d = (float)Math.hypot(dx, dy);
                    length = clamp(d * 2f, 20f, 10000f);
                    float a = (float)Math.toDegrees(Math.atan2(dy, dx));
                    angle = type == END_A ? normalize(a + 180f) : normalize(a);
                }
                updateAll();
                return true;
            }
            if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) return true;
            return true;
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("overlay_line", "Overlay Line", android.app.NotificationManager.IMPORTANCE_LOW);
            getSystemService(android.app.NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        if (wm != null) {
            try { if (handleA != null) wm.removeView(handleA); } catch (Exception ignored) {}
            try { if (handleB != null) wm.removeView(handleB); } catch (Exception ignored) {}
            try { if (handleCenter != null) wm.removeView(handleCenter); } catch (Exception ignored) {}
            try { if (lineView != null) wm.removeView(lineView); } catch (Exception ignored) {}
        }
        handleA = handleB = handleCenter = null; lineView = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}

package com.example.overlayline;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SeekBar lengthBar, angleBar;
    private TextView lengthText, angleText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setPadding(36, 36, 36, 36);

        TextView title = new TextView(this);
        title.setText("Overlay Line");
        title.setTextSize(26);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Seret bulatan di ujung garis untuk mengatur panjang + putaran. Seret bagian tengah untuk memindahkan garis.");
        info.setTextSize(16);
        info.setPadding(0, 12, 0, 20);
        root.addView(info);

        lengthText = new TextView(this);
        lengthText.setTextSize(18);
        root.addView(lengthText);

        lengthBar = new SeekBar(this);
        lengthBar.setMax(4000);
        lengthBar.setProgress(180);
        root.addView(lengthBar);

        angleText = new TextView(this);
        angleText.setTextSize(18);
        angleText.setPadding(0, 18, 0, 0);
        root.addView(angleText);

        angleBar = new SeekBar(this);
        angleBar.setMax(360);
        angleBar.setProgress(0);
        root.addView(angleBar);

        Button permission = new Button(this);
        permission.setText("Izinkan tampil di atas aplikasi lain");
        root.addView(permission);

        Button start = new Button(this);
        start.setText("Tampilkan Garis");
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Sembunyikan Garis");
        root.addView(stop);

        updateLengthText(180);
        updateAngleText(0);

        lengthBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int length = Math.max(20, progress);
                updateLengthText(length);
                Intent i = new Intent(MainActivity.this, OverlayService.class);
                i.setAction(OverlayService.ACTION_SET_LENGTH);
                i.putExtra("length", length);
                startService(i);
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });

        angleBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                updateAngleText(progress);
                Intent i = new Intent(MainActivity.this, OverlayService.class);
                i.setAction(OverlayService.ACTION_SET_ANGLE);
                i.putExtra("angle", progress);
                startService(i);
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });

        permission.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });

        start.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                Intent i = new Intent(this, OverlayService.class);
                i.setAction(OverlayService.ACTION_START);
                startForegroundService(i);
            } else {
                Intent p = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(p);
            }
        });

        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));

        setContentView(root);
    }

    private void updateLengthText(int length) { lengthText.setText("Panjang: " + length + " px"); }
    private void updateAngleText(int angle) { angleText.setText("Sudut: " + angle + "°"); }
}

package com.example.overlayline;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SeekBar lengthBar;
    private TextView valueText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setPadding(36, 36, 36, 36);

        TextView title = new TextView(this);
        title.setText("Overlay Line");
        title.setTextSize(26);
        title.setPadding(0, 0, 0, 28);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Atur panjang garis, lalu nyalakan overlay. Setelah itu kamu bisa memindahkan garis dengan menekan dan menyeretnya.");
        info.setTextSize(16);
        root.addView(info);

        valueText = new TextView(this);
        valueText.setTextSize(18);
        valueText.setPadding(0, 32, 0, 8);
        root.addView(valueText);

        lengthBar = new SeekBar(this);
        lengthBar.setMax(500);
        lengthBar.setProgress(150);
        root.addView(lengthBar, new android.widget.LinearLayout.LayoutParams(-1, -2));

        Button permission = new Button(this);
        permission.setText("Izinkan tampil di atas aplikasi lain");
        root.addView(permission);

        Button start = new Button(this);
        start.setText("Tampilkan Garis");
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Sembunyikan Garis");
        root.addView(stop);

        updateText(150);

        lengthBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int length = Math.max(20, progress);
                updateText(length);
                Intent i = new Intent(MainActivity.this, OverlayService.class);
                i.setAction(OverlayService.ACTION_SET_LENGTH);
                i.putExtra("length", length);
                startService(i);
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });

        permission.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });

        start.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                Intent i = new Intent(this, OverlayService.class);
                i.setAction(OverlayService.ACTION_START);
                startForegroundService(i);
            } else {
                Intent p = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(p);
            }
        });

        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
        });

        setContentView(root);
    }

    private void updateText(int length) {
        valueText.setText("Panjang garis: " + length + " px");
    }
}

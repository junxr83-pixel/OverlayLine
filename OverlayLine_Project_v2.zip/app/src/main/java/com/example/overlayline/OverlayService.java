package com.example.overlayline;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {
    public static final String ACTION_START = "START";
    public static final String ACTION_SET_LENGTH = "SET_LENGTH";

    private WindowManager wm;
    private LineView line;
    private WindowManager.LayoutParams params;
    private int length = 150;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, "overlay_line")
                .setContentTitle("Overlay Line aktif")
                .setContentText("Garis sedang tampil di atas aplikasi.")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setOngoing(true)
                .build();
        startForeground(1001, n);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_SET_LENGTH.equals(intent.getAction())) {
            length = Math.max(20, intent.getIntExtra("length", 150));
            if (line != null) {
                line.setLineLength(length);
            }
        } else if (line == null && Settings.canDrawOverlays(this)) {
            showLine();
        }
        return START_STICKY;
    }

    private void showLine() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                length + 40,
                24,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 120;
        params.y = 400;

        line = new LineView();
        wm.addView(line, params);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    "overlay_line", "Overlay Line", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private class LineView extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint();
        private float downX, downY;
        private int startX, startY;

        LineView() {
            super(OverlayService.this);
            paint.setColor(Color.WHITE);
            paint.setStrokeWidth(6f);
            paint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            setBackgroundColor(Color.TRANSPARENT);
        }

        void setLineLength(int px) {
            WindowManager.LayoutParams p = params;
            p.width = px + 40;
            params = p;
            if (wm != null) {
                try { wm.updateViewLayout(this, params); } catch (Exception ignored) {}
            }
            invalidate();
        }

        @Override
        protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            float centerY = getHeight() / 2f;
            canvas.drawLine(20, centerY, getWidth() - 20, centerY, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startX = params.x;
                    startY = params.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = startX + (int)(e.getRawX() - downX);
                    params.y = startY + (int)(e.getRawY() - downY);
                    try { wm.updateViewLayout(this, params); } catch (Exception ignored) {}
                    return true;
            }
            return true;
        }
    }

    @Override
    public void onDestroy() {
        if (line != null && wm != null) {
            try { wm.removeView(line); } catch (Exception ignored) {}
            line = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
